export const iso27001Controls = [

  {
    id: "A.5.1",
    title: "Information Security Policies",
    description:
      "Information security policies are defined.",
  },

  {
    id: "A.5.15",
    title: "Access Control",
    description:
      "Access rights are managed.",
  },

  {
    id: "A.5.24",
    title: "Incident Management",
    description:
      "Security incidents are handled.",
  },

  {
    id: "A.8.15",
    title: "Logging",
    description:
      "Events are logged and monitored.",
  },

  {
    id: "A.8.16",
    title: "Monitoring Activities",
    description:
      "Monitoring activities are performed.",
  },

];
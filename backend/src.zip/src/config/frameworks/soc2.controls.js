export const soc2Controls = [

  {
    id: "CC6.1",
    title: "Logical Access Controls",
    description:
      "Access to systems and data is restricted.",
  },

  {
    id: "CC7.2",
    title: "System Monitoring",
    description:
      "Security events are monitored.",
  },

  {
    id: "CC8.1",
    title: "Change Management",
    description:
      "Changes are authorized and tested.",
  },

  {
    id: "A1.2",
    title: "Risk Mitigation",
    description:
      "Risks are identified and mitigated.",
  },

  {
    id: "PI1.1",
    title: "Data Integrity",
    description:
      "Data is accurate and complete.",
  },

];
export const gdprControls = [

  {
    id: "GDPR-5",
    title: "Lawful Processing",
    description:
      "Personal data is processed lawfully.",
  },

  {
    id: "GDPR-25",
    title: "Privacy By Design",
    description:
      "Privacy controls are built into systems.",
  },

  {
    id: "GDPR-30",
    title: "Processing Records",
    description:
      "Records of processing activities exist.",
  },

  {
    id: "GDPR-32",
    title: "Security Of Processing",
    description:
      "Appropriate security measures are implemented.",
  },

  {
    id: "GDPR-33",
    title: "Breach Notification",
    description:
      "Data breaches are reported appropriately.",
  },

];
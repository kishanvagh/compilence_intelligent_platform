import path from "path";
import fs from "fs";
import Document from "../models/Document.js";
import { analyzePDF } from "../services/core/fastapi.service.js";
import { chunkText } from "../utils/chunkText.js";
import DocumentChunk from "../models/DocumentChunk.js";
import { processDocumentEmbeddings } from "../services/indexing/chunkEmbeddingProcessor.js";
import Assessment from "../models/Assessment.js";
import qdrant from "../services/core/qdrant.service.js";
export const uploadDocument = async (req, res) => {
  try {
    const absolutePath = path.resolve(req.file.path);

    const analysis = await analyzePDF(absolutePath);
    const chunksData = [];
    let chunkIndex = 0;

    if (analysis.pages && analysis.pages.length > 0) {
      for (const page of analysis.pages) {
        const pageChunks = chunkText(page.text);
        for (const pChunk of pageChunks) {
          chunksData.push({
            chunkIndex: chunkIndex++,
            text: pChunk,
            pageNumber: page.pageNumber,
          });
        }
      }
    } else {
      const chunks = chunkText(analysis.text);
      for (const chunk of chunks) {
        chunksData.push({
          chunkIndex: chunkIndex++,
          text: chunk,
          pageNumber: 1,
        });
      }
    }

    console.log("Total Chunks:", chunksData.length);
    const document = await Document.create({
      userId: req.user._id,
      originalName: req.file.originalname,
      filePath: req.file.path,
      extractedText: analysis.text,
      totalChunks: chunksData.length,
      status: "completed",
    });

    await DocumentChunk.insertMany(
      chunksData.map((c) => ({
        documentId: document._id,
        chunkIndex: c.chunkIndex,
        text: c.text,
        pageNumber: c.pageNumber,
      }))
    );

    const embeddedChunks = await processDocumentEmbeddings(document._id);
    console.log(
      `Embedded ${embeddedChunks} chunks`
    );
    res.status(201).json({
      success: true,
      document,
      analysis,
    });
  } catch (error) {
    res.status(500).json({
      message: error.message,
    });
  }
};

export const getDocuments = async (req, res) => {
  try {
    const documents = await Document.find({ userId: req.user._id }).sort({ createdAt: -1 });
    res.json({
      success: true,
      documents,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

export const deleteDocument = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user._id;

    // 1. Find document to verify ownership
    const document = await Document.findOne({ _id: id, userId });
    if (!document) {
      return res.status(404).json({
        success: false,
        message: "Document not found or you do not have permission to delete it.",
      });
    }

    // 2. Delete local PDF file
    if (document.filePath) {
      const fullPath = path.resolve(document.filePath);
      fs.unlink(fullPath, (err) => {
        if (err) {
          console.error(`Failed to delete local file at ${fullPath}:`, err.message);
        } else {
          console.log(`Deleted local file at ${fullPath}`);
        }
      });
    }

    // 3. Delete DB Records
    await Document.findByIdAndDelete(id);
    await DocumentChunk.deleteMany({ documentId: id });
    await Assessment.deleteMany({ documentId: id });

    // 4. Delete vectors from Qdrant
    try {
      await qdrant.delete("document_chunks", {
        filter: {
          must: [
            {
              key: "documentId",
              match: {
                value: id.toString(),
              },
            },
          ],
        },
      });
      console.log(`Deleted Qdrant vectors for document ${id}`);
    } catch (qdrantErr) {
      console.error(`Failed to clear Qdrant vectors for document ${id}:`, qdrantErr.message);
    }

    res.json({
      success: true,
      message: "Document, chunks, audits, and vector mappings deleted successfully.",
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};
import "dotenv/config";
import app from "./app.js";
import connectDB from "./config/db.js";
import authRoutes from "./routes/authRoutes.js";
import documentRoutes from "./routes/documentRoutes.js";
import testRoutes from "./routes/testRoutes.js"
import {
  createVectorCollection,
} from "./services/core/vectorCollection.service.js";
import qdrantRoutes
from "./routes/qdrantRoutes.js";
import retrievalRoutes
from "./routes/retrievalRoutes.js";
import ragRoutes
from "./routes/ragRoutes.js";
import complianceRoutes from "./routes/complianceRoutes.js" 
import reportRouter from "./routes/reportRoutes.js"
import trendRoutes
from "./routes/trendRoutes.js";
const PORT = process.env.PORT || 5000;

connectDB();
await createVectorCollection();
app.listen(PORT, () => {
  console.log(`Server Running On Port ${PORT}`);
});

app.use("/api/auth", authRoutes);
app.use("/api/documents", documentRoutes);
app.use("/api/test",testRoutes);
app.use(
  "/api/qdrant",
  qdrantRoutes
);
app.use(
  "/api/retrieval",
  retrievalRoutes
);
app.use(
  "/api/rag",
  ragRoutes
);

app.use("/api/compliance",complianceRoutes);

app.use("/api/reports",reportRouter);

app.use(
  "/api/trends",
  trendRoutes
);


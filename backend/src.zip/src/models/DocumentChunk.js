import mongoose from "mongoose";

const documentChunkSchema = new mongoose.Schema(
  {
    documentId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Document",
      required: true,
    },

    chunkIndex: {
      type: Number,
      required: true,
    },

    text: {
      type: String,
      required: true,
    },

    embedding: {
      type: [Number],
      default: [],
    },

    embeddingModel: {
      type: String,
      default: "gemini-embedding-001",
    },

    isEmbedded: {
      type: Boolean,
      default: false,
    },
    pageNumber: {
      type: Number,
      default: 1,
    },
    qdrantPointId: {
      type: String,
      default: null,
    },
  },
  { timestamps: true }
);

export default mongoose.model(
  "DocumentChunk",
  documentChunkSchema
);
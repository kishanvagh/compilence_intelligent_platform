import mongoose from "mongoose";

const assessmentSchema =
  new mongoose.Schema(
    {
      userId: {
        type:
          mongoose.Schema.Types.ObjectId,
        ref: "User",
        required: true,
      },

      documentId: {
        type:
          mongoose.Schema.Types.ObjectId,
        ref: "Document",
        required: true,
      },
      framework: {
        type: String,
        required: true,
      },

      documentType: {
        type: String,
        default: null,
      },

      assessmentStatus: {
        type: String,
        default: "APPLICABLE",
      },

      reason: {
        type: String,
        default: null,
      },

      riskScore: {
        type: Number,
        required: true,
      },

      compliantControls: {
        type: Number,
        default: 0,
      },

      partialControls: {
        type: Number,
        default: 0,
      },

      nonCompliantControls: {
        type: Number,
        default: 0,
      },
      notApplicableControls: {
        type: Number,
        default: 0,
      },

      totalControls: {
        type: Number,
        default: 0,
      },

      controls: {
        type: Array,
        default: [],
      },

      report: {
        type: Object,
        default: {},
      },

      createdAt: {
        type: Date,
        default: Date.now,
      },
      
    },
    {
      timestamps: true,
    }
  );

export default mongoose.model(
  "Assessment",
  assessmentSchema
);
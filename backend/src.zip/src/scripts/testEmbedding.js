import dotenv from "dotenv";
dotenv.config();
import { generateEmbedding } from "../services/core/embedding.service.js";

async function main() {
  try {
    console.log("Testing Embedding Generation...");
    const embedding = await generateEmbedding("Hello World");
    console.log("Embedding generated successfully!");
    console.log("Dimensions:", embedding.length);
    console.log("First 5 values:", embedding.slice(0, 5));
  } catch (error) {
    console.error("Embedding Error:", error);
  }
}

main();

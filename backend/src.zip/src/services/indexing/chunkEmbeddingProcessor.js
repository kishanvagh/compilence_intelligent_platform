import DocumentChunk from "../../models/DocumentChunk.js";
import { generateEmbedding } from "../core/embedding.service.js";
import { upsertChunkToQdrant } from "./qdrantUpsert.service.js";

export const processDocumentEmbeddings = async (
  documentId
) => {
  const chunks = await DocumentChunk.find({
    documentId,
    isEmbedded: false,
  });

  console.log(
    `Found ${chunks.length} chunks to embed and upsert directly to Qdrant`
  );

  for (const chunk of chunks) {
    const embedding = await generateEmbedding(
      chunk.text
    );

    // Create a temporary object containing the vector embedding
    const chunkWithEmbedding = {
      documentId: chunk.documentId,
      chunkIndex: chunk.chunkIndex,
      pageNumber: chunk.pageNumber,
      text: chunk.text,
      embedding: embedding
    };

    // Upsert directly to Qdrant
    const pointId = await upsertChunkToQdrant(chunkWithEmbedding);

    // Save index metadata in MongoDB, leaving chunk.embedding array empty
    chunk.isEmbedded = true;
    chunk.qdrantPointId = pointId;

    await chunk.save();
  }
  return chunks.length;
};

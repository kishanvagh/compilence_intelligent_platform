import qdrant from "../core/qdrant.service.js";

export const retrieveDocumentChunks = async (
  documentId,
  limit = 20
) => {

  try {

    const response =
      await qdrant.scroll(
        "document_chunks",
        {
          filter: {
            must: [
              {
                key: "documentId",
                match: {
                  value: documentId,
                },
              },
            ],
          },

          limit,
        }
      );

    const points =
      response.points || [];

    return points.map(
  point => ({
    documentId:
      point.payload.documentId,

    chunkIndex:
      point.payload.chunkIndex,

    pageNumber:
      point.payload.pageNumber || 1,

    text:
      point.payload.text,

    score:
      point.score || null
  })
);

  } catch (error) {

    console.error(
      "Compliance Retrieval Error:",
      error
    );

    throw error;
  }
};

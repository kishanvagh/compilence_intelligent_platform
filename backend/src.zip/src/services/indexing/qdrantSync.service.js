import DocumentChunk from "../../models/DocumentChunk.js";
import { generateEmbedding } from "../core/embedding.service.js";
import {
  upsertChunkToQdrant,
} from "./qdrantUpsert.service.js";

export const syncDocumentToQdrant =
  async (documentId) => {

    const chunks =
      await DocumentChunk.find({
        documentId,
      });

    console.log(
      `Syncing ${chunks.length} chunks to Qdrant`
    );

    for (const chunk of chunks) {
      let embedding = chunk.embedding;
      
      // If the vector array is empty in MongoDB, generate it on the fly for Qdrant upsert
      if (!embedding || embedding.length === 0) {
        embedding = await generateEmbedding(chunk.text);
      }

      const chunkWithEmbedding = {
        documentId: chunk.documentId,
        chunkIndex: chunk.chunkIndex,
        pageNumber: chunk.pageNumber,
        text: chunk.text,
        embedding: embedding
      };

      const pointId =
        await upsertChunkToQdrant(chunkWithEmbedding);

      chunk.qdrantPointId =
        pointId;

      await chunk.save();
    }

    return chunks.length;
  };

import qdrant from "../core/qdrant.service.js";
import { v4 as uuidv4 } from "uuid";
export const upsertChunkToQdrant = async (
  chunk
) => {
  const pointId = uuidv4();
  await qdrant.upsert(
    "document_chunks",
    {
      wait: true,

      points: [
        {
          id: pointId,

          vector: chunk.embedding,

          payload: {
            documentId:
              chunk.documentId.toString(),

            chunkIndex:
              chunk.chunkIndex,

            pageNumber:
              chunk.pageNumber || 1,

            text: chunk.text,
          },
        },
      ],
    }
  );

  return pointId;
};

import { retrieveRelevantChunks }
from "./retrieval.service.js";

import { buildContext }
from "./contextBuilder.service.js";

import ai from "../core/gemini.service.js";

export const generateRagAnswer = async (
  query,
  documentId
) => {

  try {

    // Step 1: Retrieve relevant chunks
    const retrievedChunks =
      await retrieveRelevantChunks(
        query,
        documentId
      );

    // No relevant information found
    if (!retrievedChunks.length) {

      return {
        answer:
          "I could not find relevant information in the document.",
        sources: [],
      };

    }

    // Step 2: Build context
    const context =
      buildContext(
        retrievedChunks
      );

    // Step 3: Create prompt
    const prompt = `
You are a professional compliance document intelligence assistant.

Analyze the provided document context to answer the user's question. 

Guidelines:
1. Rely on the provided context. You may make reasonable inferences based on the text (for example, if the document contains placeholders like "(Company)", bracketed text, or draft check-boxes, you can infer and explain that it is a template).
2. Keep your answer professional, clear, and direct.
3. If the context does not contain any relevant information to address the question, respond with: "I could not find that information in the document."

Context:
${context}

Question:
${query}
`;

    // Step 4: Generate answer
    const response =
      await ai.models.generateContent({
        model: "gemini-2.0-flash",
        contents: prompt,
      });

    return {
      answer: response.text,

      sources: retrievedChunks.map(
        (chunk) => ({
          documentId:
            chunk.documentId,

          chunkIndex:
            chunk.chunkIndex,

          pageNumber:
            chunk.pageNumber || 1,

          score:
            Number(
              chunk.score.toFixed(3)
            ),
          text: chunk.text,
          snippet: chunk.snippet,
        })
      ),
    };

  } catch (error) {

    console.error(
      "RAG Error:",
      error
    );

    throw error;
  }
};

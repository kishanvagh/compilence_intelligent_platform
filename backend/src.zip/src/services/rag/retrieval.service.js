import qdrant from "../core/qdrant.service.js";
import { generateEmbedding } from "../core/embedding.service.js";

export const retrieveRelevantChunks = async (
  query,
  documentId,
  limit = 10
) => {
  try {

    // Convert query into embedding
    const queryEmbedding =
      await generateEmbedding(query);

    // Search only inside the selected document
    const searchResults =
      await qdrant.search(
        "document_chunks",
        {
          vector: queryEmbedding,

          filter: {
            must: [
              {
                key: "documentId",
                match: {
                  value: documentId,
                },
              },
            ],
          },

          limit,
        }
      );

    console.log("Raw search results from Qdrant:", JSON.stringify(searchResults, null, 2));

    // Remove weak matches (using a relaxed threshold of 0.35 to ensure high recall)
    const filteredResults =
      searchResults.filter(
        result => result.score > 0.35
      );

    // Format response
    return filteredResults.map(
      result => ({
        score: result.score,

        documentId:
          result.payload.documentId,

        chunkIndex:
          result.payload.chunkIndex,

        pageNumber:
          result.payload.pageNumber || 1,

        text:
          result.payload.text,

        snippet:
          result.payload.text.slice(0, 250),
      })
    );

  } catch (error) {

    console.error(
      "Retrieval Error:",
      error
    );

    throw error;
  }
};

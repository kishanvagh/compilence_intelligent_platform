import {
  soc2Controls,
} from "../../config/frameworks/soc2.controls.js";

import {
  iso27001Controls,
} from "../../config/frameworks/iso27001.controls.js";

import {
  gdprControls,
} from "../../config/frameworks/gdpr.controls.js";

export const getFrameworkControls = (
  framework
) => {

  switch (
    framework?.toUpperCase()
  ) {

    case "SOC2":
      return soc2Controls;

    case "ISO27001":
      return iso27001Controls;

    case "GDPR":
      return gdprControls;

    default:
      return soc2Controls;

  }

};

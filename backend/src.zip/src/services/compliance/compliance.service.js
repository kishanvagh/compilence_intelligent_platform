import {
  retrieveDocumentChunks,
} from "../indexing/complianceRetrieval.service.js";

import {
  buildContext,
} from "../rag/contextBuilder.service.js";

import ai from "../core/gemini.service.js";

import {
  getFrameworkControls,
} from "./framework.service.js";

/*
|--------------------------------------------------------------------------
| Extract JSON
|--------------------------------------------------------------------------
*/

const extractJson = (
  responseText
) => {

  const cleaned =
    responseText
      .replace(/```json/g, "")
      .replace(/```/g, "")
      .trim();

  return JSON.parse(cleaned);

};

/*
|--------------------------------------------------------------------------
| Risk Score Engine
|--------------------------------------------------------------------------
*/

const calculateRiskScore = (
  controls
) => {

  let score = 0;

  controls.forEach(
    (control) => {

      switch (
        control.status
      ) {

        case "NON_COMPLIANT":
          score += 20;
          break;

        case "PARTIALLY_COMPLIANT":
          score += 10;
          break;

        case "NOT_APPLICABLE":
          score += 0;
          break;

        case "COMPLIANT":
        default:
          score += 0;
          break;

      }

    }
  );

  return Math.min(
    score,
    100
  );

};

/*
|--------------------------------------------------------------------------
| Confidence Engine
|--------------------------------------------------------------------------
*/

const addConfidenceScores = (
  controls
) => {

  return controls.map(
    (control) => {

      let confidence = 0.5;

      if (
        control.sourceChunks &&
        control.sourceChunks.length > 0
      ) {

        confidence =
          Math.min(
            0.5 +
              (
                control.sourceChunks.length *
                0.1
              ),
            0.95
          );

      }

      return {

        ...control,

        confidence:
          Number(
            confidence.toFixed(2)
          ),

      };

    }
  );

};

const resolveSourceChunks = (controls, retrievedChunks) => {
  return controls.map(control => {
    if (!control.sourceChunks || !Array.isArray(control.sourceChunks)) {
      return { ...control, sourceChunks: [] };
    }

    const resolved = control.sourceChunks.map(ref => {
      let index = -1;
      if (typeof ref === 'number') {
        index = ref;
      } else if (typeof ref === 'string') {
        const matches = ref.match(/\d+/);
        if (matches) {
          index = parseInt(matches[0], 10);
        }
      }

      if (index !== -1) {
        const found = retrievedChunks.find(c => c.chunkIndex === index);
        if (found) {
          return {
            chunkIndex: found.chunkIndex,
            pageNumber: found.pageNumber || 1,
            text: found.text,
          };
        }
      }
      return typeof ref === 'string' ? { chunkIndex: -1, pageNumber: 1, text: ref } : null;
    }).filter(Boolean);

    return {
      ...control,
      sourceChunks: resolved,
    };
  });
};

/*
|--------------------------------------------------------------------------
| Compliance Analysis
|--------------------------------------------------------------------------
*/

export const analyzeCompliance =
  async (
    documentId,
    framework = "SOC2"
  ) => {

    try {

      /*
      --------------------------------------------------
      Step 1
      Retrieve Document Chunks
      --------------------------------------------------
      */

      const retrievedChunks =
        await retrieveDocumentChunks(
          documentId,
          20
        );

      console.log(
        "Retrieved Chunks:",
        retrievedChunks.length
      );

      if (
        !retrievedChunks.length
      ) {

        return {
          framework,
          riskScore: 100,
          compliantControls: 0,
          partialControls: 0,
          nonCompliantControls: 0,
          controls: [],
          findings: [
            {
              title: "No Evidence Found",
              severity: "HIGH",
              evidence: "Unable to retrieve document content.",
            },
          ],
          recommendations: [
            "Upload a valid document.",
          ],
        };

      }

      /*
      --------------------------------------------------
      Step 2
      Build Context
      --------------------------------------------------
      */

      const context =
        buildContext(
          retrievedChunks
        );

      /*
      --------------------------------------------------
      Step 3
      Load Framework Controls
      --------------------------------------------------
      */

      const frameworkControls =
        getFrameworkControls(
          framework
        );

      /*
      --------------------------------------------------
      Step 4
      Create Single Unified Prompt
      --------------------------------------------------
      */

      const prompt = `
You are a senior compliance auditor and document classifier.

Evaluate the document evidence against the requested framework controls, perform an applicability check, and generate a gap analysis.

Framework:
${framework}

Controls:
${JSON.stringify(frameworkControls, null, 2)}

Rules for Document Classification & Applicability:
1. Classify the document. Allowed document types: RESUME, SECURITY_POLICY, ACCESS_CONTROL_POLICY, INCIDENT_RESPONSE_POLICY, VENDOR_DOCUMENT, CONTRACT, GENERAL_POLICY, GENERAL_DOCUMENT.
2. Determine if the document is applicable to compliance auditing under the framework ${framework}. If it is completely unrelated (e.g., a personal resume, recipe, fictional story, etc.), set assessmentStatus to "NOT_APPLICABLE" and write a clear classification reason.
3. If assessmentStatus is "NOT_APPLICABLE", you can return an empty list of controls.

Rules for Control Evaluation (only if assessmentStatus is "APPLICABLE"):
1. Evaluate the document evidence against EACH control.
2. Allowed control statuses: COMPLIANT, PARTIALLY_COMPLIANT, NON_COMPLIANT, NOT_APPLICABLE.
3. Use ONLY evidence from the document. Never invent evidence.
4. If evidence is insufficient, use PARTIALLY_COMPLIANT or NON_COMPLIANT.
5. If the control clearly does not apply to this type of document, use NOT_APPLICABLE.
6. For each control, identify which source chunks support your finding. Reference them by chunk indexes (e.g., ["Chunk 0", "Chunk 1"] or [0, 1]).

Rules for Gap Analysis (only for controls evaluated as PARTIALLY_COMPLIANT or NON_COMPLIANT):
1. Identify the specific gap in the policy document.
2. Highlight the associated businessRisk of not meeting the control.
3. Provide an actionable recommendation to remediate the gap.
For COMPLIANT or NOT_APPLICABLE controls, these fields should be null.

Return ONLY valid JSON.
Do NOT use markdown.
Do NOT use code fences.

Response Format:
{
  "documentType": "",
  "assessmentStatus": "APPLICABLE" or "NOT_APPLICABLE",
  "reason": "",
  "controls": [
    {
      "controlId": "",
      "controlName": "",
      "status": "",
      "risk": "",
      "evidence": "",
      "sourceChunks": [],
      "gap": null or "...",
      "businessRisk": null or "...",
      "recommendation": null or "..."
    }
  ]
}

Document Evidence:
${context}
`;

      /*
      --------------------------------------------------
      Step 5
      Gemini Retry Logic
      --------------------------------------------------
      */

      let response;

      for (
        let attempt = 1;
        attempt <= 3;
        attempt++
      ) {

        try {

          response =
            await ai.models.generateContent({
              model: "gemini-2.0-flash",
              contents: prompt,
            });

          break;

        } catch (error) {

          console.log(
            `Gemini Attempt ${attempt} Failed`
          );

          if (
            attempt === 3
          ) {
            throw error;
          }

          await new Promise(
            (resolve) =>
              setTimeout(
                resolve,
                2000
              )
          );

        }

      }

      /*
      --------------------------------------------------
      Step 6
      Parse Response
      --------------------------------------------------
      */

      const assessment =
        extractJson(
          response.text
        );

      if (assessment.assessmentStatus === "NOT_APPLICABLE") {
        return {
          framework,
          documentType: assessment.documentType,
          assessmentStatus: "NOT_APPLICABLE",
          reason: assessment.reason,
          riskScore: 0,
          compliantControls: 0,
          partialControls: 0,
          nonCompliantControls: 0,
          notApplicableControls: 0,
          totalControls: 0,
          controls: [],
        };
      }

      const resolvedControls =
        resolveSourceChunks(
          assessment.controls,
          retrievedChunks
        );

      /*
      --------------------------------------------------
      Step 7
      Add Confidence Scores
      --------------------------------------------------
      */

      const controlsWithConfidence =
        addConfidenceScores(
          resolvedControls
        );

      /*
      --------------------------------------------------
      Step 8
      Calculate Risk Score
      --------------------------------------------------
      */

      const riskScore =
        calculateRiskScore(
          controlsWithConfidence
        );

      /*
      --------------------------------------------------
      Step 9
      Metrics
      --------------------------------------------------
      */

      const compliantControls =
        controlsWithConfidence.filter(
          control =>
            control.status === "COMPLIANT"
        ).length;

      const partialControls =
        controlsWithConfidence.filter(
          control =>
            control.status === "PARTIALLY_COMPLIANT"
        ).length;

      const nonCompliantControls =
        controlsWithConfidence.filter(
          control =>
            control.status === "NON_COMPLIANT"
        ).length;

      const notApplicableControls =
        controlsWithConfidence.filter(
          control =>
            control.status === "NOT_APPLICABLE"
        ).length;

      /*
      --------------------------------------------------
      Step 10
      Return Assessment
      --------------------------------------------------
      */

      return {
        framework,
        documentType: assessment.documentType,
        assessmentStatus: assessment.assessmentStatus,
        reason: assessment.reason,
        riskScore,
        compliantControls,
        partialControls,
        nonCompliantControls,
        notApplicableControls,
        totalControls: controlsWithConfidence.length,
        controls: controlsWithConfidence,
      };

    } catch (error) {

      console.error(
        "Compliance Analysis Error:",
        error
      );

      throw error;

    }

};

export const classifyDocument =
  (documentText) => {

    const text =
      documentText.toLowerCase();

    if (
      text.includes("education") &&
      text.includes("skills") &&
      text.includes("experience")
    ) {
      return "RESUME";
    }

    if (
      text.includes("policy") ||
      text.includes("compliance")
    ) {
      return "POLICY";
    }

    if (
      text.includes("security") &&
      text.includes("incident")
    ) {
      return "SECURITY_DOCUMENT";
    }

    return "GENERAL_DOCUMENT";

};

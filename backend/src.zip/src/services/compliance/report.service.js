import ai from "../core/gemini.service.js";

export const generateComplianceReport =
  async (assessment) => {

    const prompt = `
You are a senior compliance consultant.

Given the compliance assessment below,
generate a professional report.

Return ONLY valid JSON.

Format:

{
  "executiveSummary": "",
  "overallRisk": "",
  "topRisks": [],
  "recommendations": []
}

Assessment:

${JSON.stringify(assessment, null, 2)}
`;

    const response =
      await ai.models.generateContent({
        model: "gemini-flash-latest",
        contents: prompt,
      });

    const cleaned =
      response.text
        .replace(/```json/g, "")
        .replace(/```/g, "")
        .trim();

    return JSON.parse(cleaned);

};

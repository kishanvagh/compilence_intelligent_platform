import qdrant from "./qdrant.service.js";

export const createVectorCollection = async () => {
  try {
    await qdrant.createCollection(
      "document_chunks",
      {
        vectors: {
          size: 768,
          distance: "Cosine",
        },
      }
    );

    console.log(
      "Qdrant Collection Created"
    );
  } catch (error) {
    console.log(
      "Collection already exists"
    );
  }
};

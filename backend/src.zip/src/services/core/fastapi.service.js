import axios from "axios";

const FASTAPI_URL = "http://127.0.0.1:8000";

export const analyzePDF = async (filePath) => {
  const response = await axios.post(
    `${FASTAPI_URL}/analyze`,
    {
      filePath,
    }
  );

  return response.data;
};

import express from "express";
import { generateEmbedding } from "../services/core/embedding.service.js";

const router = express.Router();

router.get("/test-embedding", async (req, res) => {
  try {
    const embedding = await generateEmbedding(
      "GDPR requires organizations to protect user data."
    );

    res.json({
      success: true,
      dimensions: embedding.length,
      sample: embedding.slice(0, 5),
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
});

export default router;